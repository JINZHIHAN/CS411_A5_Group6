const router = require('express').Router();
const passport = require('passport');
//auth login
router.get('/login', (req, res) => {
  res.render('login');
});
//auth logout
router.get('/logout', (req, res) => {
    res.send('logging out');
});

//auth with fitbit
router.get('/fitbit', passport.authenticate('fitbit',{
    scope: ['profile']

}));

//callback rout for google to redirect to
router.get('/fitbit/redirect', passport.authenticate('fitbit'),(req,res)=>{
    res.send('you reached the callback URI');
});



module.exports = router;