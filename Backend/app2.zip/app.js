const express = require('express');
const bodyParser = require('body-parser');
const consolidate = require('consolidate');
const unirest = require('unirest');
const mongoose = require('mongoose');
const keys = require('./config/keys');
const BASE_URL = 'https://spoonacular-recipe-food-nutrition-v1.p.rapidapi.com/recipes/mealplans/generate';
const RAPID_API_KEY = '14c1b8490bmsh6f286e1a513ef6dp1942a9jsn8f2e2db3c858';
const FITBIT_URL_AUTH = 'https://www.fitbit.com/oauth2/authorize';
// configure Express
const app = express();
const authRoutes = require('./routes/auth-routes');
const passportSetup = require('./config/passport-setup');
//connect to mongodb
mongoose.connect(keys.mongodb.dbURI, () => {
    console.log('connected to mongodb');
});
//set up routes
app.use('/auth', authRoutes);

app.set('views', __dirname + '/views');
app.engine('html', consolidate.swig);
//set view engine
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
//this is our server
app.get('/', (req, res) => {
    res.render('home');
});


app.post('/', (req, res) => {
    const calories = req.body.calorie_input;

    unirest.get(BASE_URL + '?timeFrame=day&targetCalories=' + calories)
        .header('X-RapidAPI-Key', RAPID_API_KEY)
        .end((result) => {
            console.log(result.headers, result.body);
            res.render('search.html', {
                results: JSON.stringify(result.body, null, 2),
            });
        });
});

//mock the first unirest.get, second .get needs to be in the fitbit.end
//do result.body.keys
//type in phone number to app?
//first time = oAuth from fitbit
//then from then on use phone number as unique for MongoDB
//When go on app, enter phone number, database lookup if oAuth token.  If there is, use fitbit API with token, feed into next call.
//If not one, make a different call to give me an oAuth token
//if expired, use special code
app.listen(6969, () => {
    console.log('App listening on port 6969!');
    console.log('Navigate to http://localhost:6969');
    // get the url


});

