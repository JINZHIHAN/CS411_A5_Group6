const passport = require('passport');
//const FitbitStrategy = require('passport-fitbit-oauth2');
var FitbitStrategy = require('passport-fitbit-oauth2').FitbitOAuth2Strategy;
const keys = require('./keys');
const User = require('../models/user-model');
const CLIENT_ID = '22DH7W';
const CLIENT_SECRET = '8a879356937013ccaf4ad5012c295903';

passport.use(
    new FitbitStrategy({
        //options for fitbit strat
        callbackURL:"auth/fitbit/redirect",
        clientID: keys.fitbit.clientID,
        clientSecret: keys.fitbit.clientSecret,

    }, (accessToken,refreshToken,profile,done) => {
        console.log('passport callback function fired');
        console.log(profile);
        new User({
            username: profile.displayName,
            fitbitId: profile.id
        }).save().then((newUser) => {
            console.log('new user created:' + newUser);
        })
    })
)

