//add this file to .gitignore

module.exports = {
    fitbit: {
        clientID: '22DH7W',
        clientSecret: '8a879356937013ccaf4ad5012c295903'
    },
    mongodb: {
        dbURI: 'mongodb+srv://chompy:chomp@cs411-project-q9d3u.mongodb.net/test?retryWrites=true'
    },
    facebook:{
        clientID: '1086841474852956',
        clientSecret: 'ea769811853ec6e1b8bc0e0a91767251'
    },
    session:{
        cookieKey: 'chomped'
    }

};